import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { expect, test, type Page } from '@playwright/test';

/**
 * Stage 4 聚焦浏览器套件（三条连贯流程）。
 *
 * - 每条流程使用独立的浏览器上下文（干净的本机资料），不接触真实用户数据；
 * - 时钟用 `page.clock` 控制：跨"每日 05:00 游戏刷新"时推进真实 epoch，
 *   而不是改一个日期字符串；
 * - 只跑这一个套件，不重复跑历史 e2e。
 */

const GAME_START = new Date('2026-03-10T04:00:00Z'); // 上海 12:00 → 游戏日 2026-03-10
const BEFORE_REFRESH = new Date('2026-03-10T20:30:00Z'); // 上海 03-11 04:30 → 仍是游戏日 03-10
const AFTER_REFRESH = new Date('2026-03-10T21:30:00Z'); // 上海 03-11 05:30 → 游戏日 03-11
const OUTPUT_DIR = path.resolve(process.cwd(), '../output/interop-uf036-038/stage4');

async function boot(page: Page) {
  await page.clock.install({ time: GAME_START });
  await page.goto('/');
  await expect(page.getByRole('heading', { name: '今日事项' })).toBeVisible();
}

async function openTemplates(page: Page) {
  await page.getByRole('button', { name: '模板库' }).click();
  await expect(page.getByRole('heading', { name: '模板库' })).toBeVisible();
}

async function createTemplateWithTitle(page: Page) {
  await openTemplates(page);
  await page.getByRole('button', { name: '新建模板' }).click();
  const dialog = page.getByRole('dialog', { name: '新建模板' });
  await dialog.getByLabel('游戏名称').fill('原神');
  await dialog.getByLabel(/默认订单标题/).fill('自动带入标题');
  await dialog.getByLabel('任务标题').first().fill('抽卡');
  await dialog.getByLabel('进度类型').first().selectOption('NUMERIC');
  await dialog.getByLabel('数值口径').first().selectOption('CUMULATIVE');
  await dialog.getByLabel('目标').first().fill('100');
  await dialog.getByRole('button', { name: '保存模板' }).click();
  await expect(dialog).toBeHidden();
}

async function createOwnerWithAccount(
  page: Page,
  ownerName: string,
  options: { category?: string; uid?: string } = {},
) {
  await page.getByRole('button', { name: '老板与账号' }).click();
  await page.getByRole('button', { name: '新建老板' }).first().click();
  await page.getByLabel('昵称').fill(ownerName);
  await page.getByRole('button', { name: '保存', exact: true }).click();
  await expect(page.getByText(ownerName).first()).toBeVisible();
  await page.getByText(ownerName).first().click();
  await expect(page.getByRole('heading', { name: ownerName })).toBeVisible();

  await page.getByRole('button', { name: '添加账号' }).first().click();
  const dialog = page.getByRole('dialog', { name: '添加游戏账号' });
  await dialog.getByLabel('游戏名称').fill('原神');
  await dialog.getByLabel('区服').fill('官服');
  await dialog.getByLabel('UID').fill(options.uid ?? '9001');
  await dialog.getByLabel('登录账号').fill(`acc-${options.uid ?? '9001'}`);
  await dialog.locator('input[type="password"]').fill('secret');
  if (options.category) {
    await dialog.getByRole('button', { name: '新建账号分类' }).click();
    await dialog.getByLabel('新分类名称').fill(options.category);
    await dialog.getByRole('button', { name: '创建并选用' }).click();
  }
  await dialog.getByRole('button', { name: '保存账号' }).click();
  await expect(page.getByRole('heading', { name: '游戏账号信息' })).toBeVisible();
}

async function openOrderEditor(page: Page) {
  await page.getByRole('button', { name: '下单' }).click();
  const dialog = page.getByRole('dialog', { name: '新建订单' });
  await expect(dialog).toBeVisible();
  return dialog;
}

test('流程1：模板标题 → 分类账号 → 计次订单 → 跨刷新累计 → 重启 → 加密导出', async ({
  page,
}) => {
  await boot(page);
  await createTemplateWithTitle(page);
  await createOwnerWithAccount(page, '流程老板', { category: '流程分类', uid: '9001' });

  const editor = await openOrderEditor(page);
  await editor.getByLabel('套用模板').selectOption({ label: '原神 · 2026.10' });
  // UF-036：模板默认标题自动带入（来源是显式状态，不是字符串比较）。
  await expect(editor.getByLabel('订单标题')).toHaveValue('自动带入标题');
  await editor.getByLabel('服务模式').selectOption('count');
  await editor.getByLabel('服务次数').fill('1');
  await editor.getByLabel('本期价格（元）').fill('100');
  await editor.getByRole('checkbox').uncheck();
  await editor.getByRole('button', { name: '创建订单' }).click();
  await expect(page.getByRole('heading', { name: '自动带入标题' })).toBeVisible();

  // UF-038：输入的是"当前累计总值"，10 之后在**次日**再记 20，结果 20（不是 30）。
  const input = page.getByLabel('抽卡 当前累计总值');
  await input.fill('10');
  await page.getByRole('button', { name: '记录总值' }).click();
  await expect(page.getByText(/10 \/ 100/).first()).toBeVisible();

  // 跨"游戏日刷新"：先推进到刷新前（仍是 03-10），再推进到刷新后（03-11）。
  await page.clock.setSystemTime(BEFORE_REFRESH);
  await page.getByRole('button', { name: '今日事项' }).click();
  await page.getByRole('button', { name: '刷新', exact: true }).click();
  await expect(page.getByText(/游戏日 2026-03-10/)).toBeVisible();
  await expect(page.getByLabel('抽卡 当前累计总值')).toHaveValue('10');

  await page.clock.setSystemTime(AFTER_REFRESH);
  await page.getByRole('button', { name: '刷新', exact: true }).click();
  await expect(page.getByText(/游戏日 2026-03-11/)).toBeVisible();
  // 刷新后值不重置。
  await expect(page.getByLabel('抽卡 当前累计总值')).toHaveValue('10');

  // 新的一天继续记录当前总值：10 → 20，仍是 20。
  await page.getByRole('button', { name: '自动带入标题' }).first().click();
  await expect(page.getByRole('heading', { name: '自动带入标题' })).toBeVisible();
  await page.getByLabel('抽卡 当前累计总值').fill('20');
  await page.getByRole('button', { name: '记录总值' }).click();
  await expect(page.getByText(/20 \/ 100/).first()).toBeVisible();
  await expect(page.getByText(/30 \/ 100/)).toHaveCount(0);

  // 浏览器重启（整页重载）后总值与两天的事件历史仍在。
  await page.reload();
  await page.getByRole('button', { name: '订单' }).click();
  await page.getByText('自动带入标题').first().click();
  await expect(page.getByLabel('抽卡 当前累计总值')).toHaveValue('20');
  await expect(page.getByText(/2026-03-10 · 记录 · 10/)).toBeVisible();
  await expect(page.getByText(/2026-03-11 · 记录 · 20/)).toBeVisible();

  // 生产加密导出：真实下载文件 + 记录哈希（供证据索引）。
  mkdirSync(OUTPUT_DIR, { recursive: true });
  await page.getByRole('button', { name: '资料与设置' }).click();
  await page.getByLabel('密码（可选）').fill('stage4-browser-password');
  await page.getByLabel('确认密码').fill('stage4-browser-password');
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.getByRole('button', { name: '导出完整备份' }).click(),
  ]);
  const target = path.join(OUTPUT_DIR, 'stage4-browser-encrypted.dgbk');
  await download.saveAs(target);
  const bytes = readFileSync(target);
  expect(bytes.length).toBeGreaterThan(500);
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  console.log(`browser encrypted export: ${bytes.length} bytes sha256=${sha256}`);
});

test('流程2：累计历史更正/撤销 → 完成态与轮次重新打开', async ({ page }) => {
  await boot(page);
  await createOwnerWithAccount(page, '更正老板', { uid: '9100' });
  const editor = await openOrderEditor(page);
  await editor.getByLabel('服务模式').selectOption('count');
  await editor.getByLabel('服务次数').fill('1');
  await editor.getByLabel('本期价格（元）').fill('50');
  await editor.getByRole('checkbox').uncheck();
  await editor.getByRole('button', { name: '添加任务' }).click();
  await editor.getByLabel('任务标题').first().fill('抽卡');
  await editor.getByLabel('进度类型').first().selectOption('NUMERIC');
  await editor.getByLabel('数值口径').first().selectOption('CUMULATIVE');
  await editor.getByLabel('目标').first().fill('10');
  await editor.getByLabel('订单标题').fill('更正流程');
  await editor.getByRole('button', { name: '创建订单' }).click();
  await expect(page.getByRole('heading', { name: '更正流程' })).toBeVisible();

  const input = page.getByLabel('抽卡 当前累计总值');
  await input.fill('10');
  await page.getByRole('button', { name: '记录总值' }).click();
  await expect(page.getByText('已达标').first()).toBeVisible();
  await expect(page.getByText(/第 1 次打卡 · .* 已完成/).first()).toBeVisible();

  // 更正为更低值：重开完成态（历史追加，不覆盖）。
  await page.getByRole('button', { name: '更正', exact: true }).first().click();
  await page.getByLabel('更正为').fill('4');
  await page.getByRole('button', { name: '保存更正' }).click();
  await expect(page.getByText('未达标').first()).toBeVisible();
  await expect(page.getByText(/4 \/ 10/).first()).toBeVisible();
  await expect(page.getByText(/第 1 次打卡 · .* 未完成/).first()).toBeVisible();

  // 撤销"更正"这条观测：撤回**不复活**被取代的旧值（契约 D-30），回到起始值 0。
  await page.getByRole('button', { name: '撤销', exact: true }).first().click();
  await expect(page.getByText('未达标').first()).toBeVisible();
  await expect(page.getByText(/0 \/ 10/).first()).toBeVisible();

  // 轮次已按证据重开，可以重新记录当前总值 10 → 完成态再次成立。
  await page.getByLabel('抽卡 当前累计总值').fill('10');
  await page.getByRole('button', { name: '记录总值' }).click();
  await expect(page.getByText('已达标').first()).toBeVisible();
});

test('流程3：分类删除/改派保留账号与订单；窄屏可用', async ({ page }) => {
  await boot(page);
  await createOwnerWithAccount(page, '分类甲', { category: '长期客户', uid: '9201' });

  // 同一账号下一张订单，用于验证删分类不影响订单。
  const editor = await openOrderEditor(page);
  await editor.getByLabel('服务模式').selectOption('count');
  await editor.getByLabel('服务次数').fill('2');
  await editor.getByLabel('本期价格（元）').fill('80');
  await editor.getByRole('checkbox').uncheck();
  await editor.getByRole('button', { name: '添加任务' }).click();
  await editor.getByLabel('任务标题').first().fill('签到');
  await editor.getByLabel('订单标题').fill('分类流程订单');
  await editor.getByRole('button', { name: '创建订单' }).click();
  await expect(page.getByRole('heading', { name: '分类流程订单' })).toBeVisible();

  await createOwnerWithAccount(page, '分类乙', { uid: '9202' });
  await page.getByRole('button', { name: '老板与账号' }).click();
  await page.getByRole('button', { name: '按账号' }).click();
  await expect(page.getByText(/UID 9201/)).toBeVisible();
  await expect(page.getByText(/UID 9202/)).toBeVisible();
  await expect(
    page.locator('li').filter({ hasText: 'UID 9201' }).getByText('长期客户').first(),
  ).toBeVisible();

  // 改派：把 9202 也归入同一分类（行内 Badge 立即反映，身份仍是 accountId）。
  await page.getByLabel('调整 原神 官服 分类').last().selectOption({ label: '长期客户' });
  await expect(
    page.locator('li').filter({ hasText: 'UID 9202' }).getByText('长期客户').first(),
  ).toBeVisible();
  await expect(
    page.locator('li').filter({ hasText: 'UID 9201' }).getByText('长期客户').first(),
  ).toBeVisible();

  // 删除分类：两个账号都保留为未分类，订单仍在。
  await page.getByRole('button', { name: '管理分类' }).click();
  const managing = page.getByRole('dialog', { name: '管理账号分类' });
  await managing.getByRole('button', { name: '删除' }).first().click();
  await managing.getByRole('button', { name: '确认删除' }).click();
  await expect(managing.getByText('还没有分类。')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByText(/UID 9201/)).toBeVisible();
  await expect(page.getByText(/UID 9202/)).toBeVisible();
  // 分类删除后账号仍在，只是分类选择回到未分类（''）。
  await expect(page.getByLabel('调整 原神 官服 分类').first()).toHaveValue('');
  await expect(page.getByLabel('调整 原神 官服 分类').last()).toHaveValue('');

  await page.getByRole('button', { name: '按老板查看' }).click();
  await page.getByText('分类甲').first().click();
  await expect(page.getByText('分类流程订单').first()).toBeVisible();

  // 窄屏检查一次：账号视图与分类操作仍可达，且没有横向溢出。
  await page.setViewportSize({ width: 390, height: 844 });
  await page
    .getByRole('navigation', { name: '底部导航' })
    .getByRole('button', { name: '老板' })
    .click();
  await page.getByRole('button', { name: '按账号' }).click();
  await expect(page.getByText(/UID 9201/)).toBeVisible();
  await expect(page.getByRole('button', { name: '管理分类' })).toBeVisible();
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - window.innerWidth,
  );
  expect(overflow).toBeLessThanOrEqual(1);
});
