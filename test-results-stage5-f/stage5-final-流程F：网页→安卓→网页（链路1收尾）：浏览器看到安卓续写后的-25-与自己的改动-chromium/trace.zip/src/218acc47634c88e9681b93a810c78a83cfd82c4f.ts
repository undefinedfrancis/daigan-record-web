import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { expect, test, type Page } from '@playwright/test';

/**
 * Stage 5 — closing legs of both chains, in a real browser.
 *
 * These run **after** the Android receiver pass, because they consume the archives the
 * Android production export produced from the browser's own data. They restore through
 * the Settings UI and verify the persisted rows, the UI and a business read before
 * exporting again (no manual record creation anywhere).
 *
 * Files consumed:
 * - `android-chain1-continued.dgbk` — Android restored the browser's continuation, wrote
 *   one more absolute total (25) and exported. The browser must see 25 and its own edits.
 * - `android-chain2-noedit-echo.dgbk` — Android restored the browser-native dataset and
 *   re-exported without edits. The browser must see exactly its own dataset.
 */

const GAME_START = new Date('2026-03-11T04:00:00Z'); // Shanghai 12:00 → game day 2026-03-11
const OUTPUT_DIR = path.resolve(process.cwd(), '../output/interop-uf036-038/stage5');
const ANDROID_FIXTURES = path.resolve(
  process.cwd(),
  '../../代肝记录软件/output/interop-fixtures/stage5',
);

async function boot(page: Page) {
  await page.clock.install({ time: GAME_START });
  await page.goto('/');
  await expect(page.getByRole('heading', { name: '今日事项' })).toBeVisible();
}

async function gotoSection(page: Page, name: '今日事项' | '订单' | '资料与设置') {
  const nav = name === '资料与设置' ? '次导航' : '主导航';
  await page
    .getByRole('navigation', { name: nav })
    .getByRole('button', { name, exact: true })
    .click();
}

async function restoreBackup(page: Page, filePath: string, password?: string) {
  await gotoSection(page, '资料与设置');
  await page.locator('input[type=file][accept*="dgbk"]').setInputFiles(filePath);
  await expect(page.getByText(/已选择：/)).toBeVisible();
  if (password) await page.getByLabel('备份密码').fill(password);
  await page.getByRole('button', { name: '预览恢复内容' }).click();
  const modal = page.getByRole('dialog', { name: '确认替换本机资料' });
  await expect(modal).toBeVisible({ timeout: 30_000 });
  await modal.getByRole('checkbox').check();
  await modal.getByRole('button', { name: '替换本机资料' }).click();
  await expect(page.getByText('已切换到恢复的资料')).toBeVisible({ timeout: 30_000 });
}

async function exportBackup(page: Page, fileName: string) {
  await gotoSection(page, '资料与设置');
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.getByRole('button', { name: '导出完整备份' }).click(),
  ]);
  const target = path.join(OUTPUT_DIR, fileName);
  await download.saveAs(target);
  const bytes = readFileSync(target);
  expect(bytes.length).toBeGreaterThan(500);
  console.log(
    `browser export ${fileName}: ${bytes.length} bytes sha256=${createHash('sha256').update(bytes).digest('hex')}`,
  );
}

test('流程F：网页→安卓→网页（链路1收尾）：浏览器看到安卓续写后的 25 与自己的改动', async ({
  page,
}) => {
  mkdirSync(OUTPUT_DIR, { recursive: true });
  await boot(page);
  await restoreBackup(page, path.join(ANDROID_FIXTURES, 'android-chain1-continued.dgbk'));

  // The browser's own continuation edits survived the Android round trip.
  await gotoSection(page, '订单');
  await expect(page.getByText('网页续用订单').first()).toBeVisible();
  await page.getByText('网页续用订单').first().click();
  await expect(page.getByRole('heading', { name: '网页续用订单' })).toBeVisible();
  // Android wrote one more absolute total (25) on the next game day: it must win.
  await expect(page.getByText(/25 \/ 100/).first()).toBeVisible();
  // The historical correction chain is intact (both platforms' corrections).
  await expect(page.getByText(/2026-03-10 · 第 1 次打卡 · 更正 · 8/)).toBeVisible();

  // Category rename performed on Android is visible in the browser.
  await gotoSection(page, '订单');
  const data = await page.evaluate(async () => {
    const databases = await indexedDB.databases();
    const name = databases
      .map((database) => database.name ?? '')
      .find((value) => value.startsWith('daigan-data-'))!;
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open(name);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const read = (store: string) =>
      new Promise<Record<string, unknown>[]>((resolve, reject) => {
        const tx = db.transaction(store, 'readonly');
        const request = tx.objectStore(store).getAll();
        request.onsuccess = () => resolve(request.result as Record<string, unknown>[]);
        request.onerror = () => reject(request.error);
      });
    const rows = {
      categories: await read('account_categories'),
      receipts: await read('receipts'),
      events: await read('task_progress_events'),
    };
    db.close();
    return rows;
  });
  const categoryNames = data.categories.map((row) => row.name);
  expect(categoryNames).toContain('安卓改名分类');
  expect(categoryNames).not.toContain('主号');
  // The Android receipt amendment became a new effective receipt row (audit kept).
  expect(data.receipts.length).toBeGreaterThanOrEqual(3);
  // Android's 25 plus the browser's own events are all present.
  expect(data.events.some((event) => event.totalValue === '25')).toBe(true);

  await exportBackup(page, 'web-chain1-final.dgbk');
});

test('流程G：网页→安卓→网页（链路2收尾）：安卓回传的无编辑数据集在浏览器中一致可用', async ({
  page,
}) => {
  mkdirSync(OUTPUT_DIR, { recursive: true });
  await boot(page);
  await restoreBackup(page, path.join(ANDROID_FIXTURES, 'android-chain2-noedit-echo.dgbk'));

  await gotoSection(page, '订单');
  await expect(page.getByText('网页打卡单').first()).toBeVisible();
  await expect(page.getByText('网页日期单').first()).toBeVisible();
  await expect(page.getByText('网页短期单').first()).toBeVisible();

  // Absolute totals survived the Android round trip unchanged.
  await page.getByText('网页打卡单').first().click();
  await expect(page.getByRole('heading', { name: '网页打卡单' })).toBeVisible();
  await expect(page.getByText(/15 \/ 100/).first()).toBeVisible();

  // The real JPEG still renders (bytes, not a marker).
  await gotoSection(page, '订单');
  await page.getByText('网页短期单').first().click();
  await page.getByRole('button', { name: '截图', exact: true }).click();
  const photos = page.getByRole('dialog', { name: '截图', exact: true });
  await expect(photos.locator('figure')).toHaveCount(1);
  const width = await photos.locator('img').first().evaluate((image) => {
    const element = image as HTMLImageElement;
    return element.naturalWidth;
  });
  expect(width).toBeGreaterThan(0);
  await page.keyboard.press('Escape');

  await exportBackup(page, 'web-chain2-final.dgbk');
});
